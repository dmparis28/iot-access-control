/**
 * This is the Phase 1.5 "AuthorizeAccess" Lambda function.
 *
 * It now has new logic to check for an "expirationTimestamp"
 * and return a new "EXPIRED" status.
 *
 * It also uses the DocumentClient to fix the 500 Internal Server Error.
 */

// Import the AWS SDK for DynamoDB
const { DynamoDBClient, GetItemCommand } = require("@aws-sdk/client-dynamodb");
// --- FIX: Import the DynamoDBDocumentClient ---
const { DynamoDBDocumentClient } = require("@aws-sdk/lib-dynamodb");

// Get the DynamoDB table name from the environment variable
const TABLE_NAME = process.env.TABLE_NAME;

// --- FIX: Use the DocumentClient ---
const baseClient = new DynamoDBClient({});
// The DocumentClient simplifies working with items in DynamoDB
const dbDocClient = DynamoDBDocumentClient.from(baseClient);
// --- END FIX ---

exports.handler = async (event) => {
  console.log("Received event:", JSON.stringify(event, null, 2));

  let requestBody;
  try {
    requestBody = JSON.parse(event.body);
  } catch (e) {
    console.error("Failed to parse request body:", e);
    return formatResponse(400, { status: "ERROR", message: "Invalid request body" });
  }

  const accessCode = requestBody.accessCode;
  const hardwareId = requestBody.hardwareId;

  if (!accessCode || !hardwareId) {
    return formatResponse(400, { status: "ERROR", message: "Missing accessCode or hardwareId" });
  }

  // Set up the parameters for the GetItem operation
  const params = {
    TableName: TABLE_NAME,
    Key: {
      "accessCode": accessCode // --- FIX: DocumentClient just needs the value ---
    }
  };

  try {
    // 1. Query the DynamoDB table
    console.log(`Checking for code: ${accessCode}`);
    // --- FIX: Use the dbDocClient and GetCommand ---
    const { Item } = await dbDocClient.send(new GetItemCommand(params));
    // --- END FIX ---

    // 2. Check if the item was found
    if (Item) {
      // --- FIX: No 'unmarshall' needed! 'Item' is already a clean JSON object. ---
      const foundItem = Item; 
      console.log(`SUCCESS: Code ${accessCode} found. Item:`, foundItem);

      // Check for our new "expirationTimestamp" feature
      if (foundItem.expirationTimestamp) {
        // Get the current time in Unix seconds
        const currentTime = Math.floor(Date.now() / 1000);
        
        if (currentTime > foundItem.expirationTimestamp) {
          console.warn(`DENIED: Code ${accessCode} is EXPIRED.`);
          // This is our new "function" or response type
          return formatResponse(403, { status: "EXPIRED" });
        }
      }
      
      // If we're here, the code is valid and not expired.
      // This is our standard "relay command"
      return formatResponse(200, { status: "OPEN" });

    } else {
      // Item does not exist. Deny.
      console.warn(`DENIED: Code ${accessCode} not found.`);
      return formatResponse(401, { status: "DENIED" });
    }

  } catch (error) {
    console.error("Error communicating with DynamoDB:", error);
    return formatResponse(500, { status: "ERROR", message: "Internal server error" });
  }
};

/**
 * Helper function to format the response for API Gateway (HTTP API).
 */
function formatResponse(statusCode, body) {
  return {
    statusCode: statusCode,
    headers: {
      "Content-Type": "application/json"
    },
    body: JSON.stringify(body)
  };
}