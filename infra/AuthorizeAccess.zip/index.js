/**
 * This is the Phase 1.5 "AuthorizeAccess" Lambda function.
 *
 * It now has new logic to check for an "expirationTimestamp"
 * and return a new "EXPIRED" status.
 */

const { DynamoDBClient, GetItemCommand } = require("@aws-sdk/client-dynamodb");
const { unmarshall } = require("@aws-aws-sdk/util-dynamodb");

const TABLE_NAME = process.env.TABLE_NAME;
const dbClient = new DynamoDBClient({});

exports.handler = async (event) => {
  console.log("Received event:", JSON.stringify(event, null, 2));

  let requestBody;
  try {
    requestBody = JSON.parse(event.body);
  } catch (e) {
    console.error("Failed to parse request body:", e);
    return formatResponse(400, { status: "ERROR", message: "Invalid request body" });
  }

  const accessCode = requestBody.accessCode;
  const hardwareId = requestBody.hardwareId;

  if (!accessCode || !hardwareId) {
    return formatResponse(400, { status: "ERROR", message: "Missing accessCode or hardwareId" });
  }

  const params = {
    TableName: TABLE_NAME,
    Key: {
      "accessCode": { S: accessCode }
    }
  };

  try {
    console.log(`Checking for code: ${accessCode}`);
    const { Item } = await dbClient.send(new GetItemCommand(params));

    if (Item) {
      // --- NEW LOGIC STARTS HERE ---
      const foundItem = unmarshall(Item);
      console.log(`SUCCESS: Code ${accessCode} found. Item:`, foundItem);

      // Check for our new "expirationTimestamp" feature
      if (foundItem.expirationTimestamp) {
        // Get the current time in Unix seconds
        const currentTime = Math.floor(Date.now() / 1000);
        
        if (currentTime > foundItem.expirationTimestamp) {
          console.warn(`DENIED: Code ${accessCode} is EXPIRED.`);
          // This is our new "function" or response type
          return formatResponse(403, { status: "EXPIRED" });
        }
      }
      
      // If we're here, the code is valid and not expired.
      // This is our standard "relay command"
      return formatResponse(200, { status: "OPEN" });
      // --- NEW LOGIC ENDS HERE ---

    } else {
      // Item does not exist. Deny.
      console.warn(`DENIED: Code ${accessCode} not found.`);
      return formatResponse(401, { status: "DENIED" });
    }

  } catch (error) {
    console.error("Error communicating with DynamoDB:", error);
    return formatResponse(500, { status: "ERROR", message: "Internal server error" });
  }
};

/**
 * Helper function to format the response for API Gateway (HTTP API).
 */
function formatResponse(statusCode, body) {
  return {
    statusCode: statusCode,
    headers: {
      "Content-Type": "application/json"
    },
    body: JSON.stringify(body)
  };
}